<?php

namespace Firebase\Dig_Firebase;

class BeforeValidException extends \UnexpectedValueException {

}
