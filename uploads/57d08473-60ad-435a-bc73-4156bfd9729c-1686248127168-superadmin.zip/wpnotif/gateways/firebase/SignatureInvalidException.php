<?php

namespace Firebase\Dig_Firebase;

class SignatureInvalidException extends \UnexpectedValueException {

}
